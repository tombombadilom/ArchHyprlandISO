# Generate GRUB configuration
grub-mkconfig -o /boot/grub/grub.cfg
