append_path '/usr/lib/rustup/bin'
export PATH
