
# Clonage et Installation Personnalisée d'Arch Linux sur USB

## Option 2: Réduire la Taille de l'Installation pour Clonage sur USB

Cette méthode implique de réduire la taille de votre installation actuelle pour qu'elle tienne sur une clé USB, puis de l'y cloner en utilisant `rsync`.

### Étapes:

1. **Nettoyer l'installation existante:**
   - Supprimez les paquets inutiles et nettoyez les fichiers temporaires et les caches :
     ```
     sudo pacman -Rns \$(pacman -Qtdq)
     sudo pacman -Sc
     ```

2. **Créer et monter une partition sur la clé USB:**
   - Identifiez votre clé USB avec `lsblk`.
   - Formatez la clé (ceci supprimera toutes les données sur la clé USB) :
     ```
     sudo mkfs.ext4 /dev/sdx1
     ```
   - Montez la partition :
     ```
     sudo mount /dev/sdx1 /mnt/usb
     ```

3. **Utiliser `rsync` pour cloner l'installation:**
   - Synchronisez les fichiers en excluant ceux non nécessaires :
     ```
     sudo rsync -aAXv --exclude={"/dev/*","/proc/*","/sys/*","/tmp/*","/run/*","/mnt/*","/media/*","/lost+found"} / /mnt/usb
     ```

4. **Installer GRUB sur la clé USB:**
   - Cela rendra la clé USB amorçable :
     ```
     sudo grub-install --target=i386-pc --recheck --boot-directory=/mnt/usb/boot /dev/sdx
     sudo grub-mkconfig -o /mnt/usb/boot/grub/grub.cfg
     ```

## Option 3: Créer une Image ISO Personnalisée avec Archiso

**Archiso** est un outil pour créer des images live/bootables d'Arch Linux.

### Étapes:

1. **Installation d'Archiso:**
   ```
   sudo pacman -S archiso
   ```

2. **Copier les fichiers de configuration nécessaires:**
   ```
   cp -r /usr/share/archiso/configs/releng/ ~/archlive
   ```

3. **Personnaliser la configuration:**
   - Modifiez les fichiers dans `~/archlive` pour inclure vos scripts, vos paquets, et vos fichiers de configuration.

4. **Construire l'image ISO:**
   ```
   cd ~/archlive
   sudo ./build.sh -v
   ```

5. **Écrire l'image ISO sur la clé USB:**
   ```
   sudo dd if=~/archlive/out/archlinux-*.iso of=/dev/sdx bs=4M status=progress oflag=sync
   ```

Pour plus de détails sur l'utilisation d'Archiso, consultez la page de documentation officielle d'Archiso sur ArchWiki.
