
# Configurer Archiso pour inclure un dépôt GitHub et exécuter des scripts

Pour personnaliser Archiso afin d'inclure la récupération d'un répertoire GitHub et l'exécution de scripts personnalisés lors de la création d'une image ISO d'Arch Linux, suivez ces étapes détaillées.

## 1. Installation et configuration initiale d'Archiso

Si Archiso n'est pas déjà installé, commencez par l'installer avec la commande suivante :
```bash
sudo pacman -S archiso
```

Ensuite, copiez les fichiers de configuration par défaut pour modification :
```bash
cp -r /usr/share/archiso/configs/releng/ ~/archlive
```

## 2. Modification du script `customize_airootfs.sh`

Ouvrez le fichier `~/archlive/airootfs/root/customize_airootfs.sh` pour y ajouter des commandes personnalisées :
```bash
nano ~/archlive/airootfs/root/customize_airootfs.sh
```

Ajoutez les commandes suivantes à la fin du fichier pour installer `git`, cloner un dépôt GitHub, exécuter un script, et nettoyer :
```bash
#!/bin/bash

# Assurez-vous que git est installé
pacman -Sy --noconfirm git

# Cloner le répertoire GitHub
git clone https://github.com/user/repo.git /root/repo

# Changer les permissions du script et l'exécuter
chmod +x /root/repo/nom_du_script.sh
/root/repo/nom_du_script.sh

# Nettoyer si nécessaire
rm -rf /root/repo
```

## 3. Construire l'image ISO

Retournez à la racine du répertoire Archiso et lancez la construction de l'image ISO :
```bash
cd ~/archlive
sudo ./build.sh -v
```

## 4. Tester l'image ISO

Après construction, testez l'image ISO avec un logiciel de machine virtuelle ou sur un USB pour vous assurer que tout fonctionne correctement.

## Résumé

Ces étapes vous permettent de personnaliser Archiso pour inclure des processus d'installation automatisés, très utiles pour le déploiement rapide sur plusieurs machines.

## Configurer Calamares pour l'installation graphique

Pour intégrer Calamares, un installateur graphique, dans votre image ISO personnalisée d'Arch Linux, suivez ces étapes pour utiliser les configurations existantes ou créer les vôtres.

### 1. Identifier les fichiers de configuration de Calamares

Les configurations de Calamares sont généralement stock*/ées dans `/etc/calamares/`. Ce répertoire contient :

- **settings.conf** : Le fichier principal qui configure les modules.
- **Modules configuration** : Fichiers YAML spécifiques pour chaque module.

### 2. Récupérer les configurations existantes

Si accessible, copiez ces configurations depuis une installation existante ou depuis l'ISO originale :

```bash
sudo cp -r /etc/calamares /chemin/de/destination
```

### 3. Adapter les configurations pour votre ISO

Modifiez les configurations récupérées selon les besoins de votre projet :

- Ajustez les chemins, les étapes d'installation, et les paramètres régionaux.
- Assurez-vous que les modifications correspondent à l'environnement de votre ISO.

### 4. Intégrer Calamares dans votre projet Archiso

Intégrez Calamares et ses configurations dans votre image ISO en modifiant `customize_airootfs.sh` :

```bash
#!/bin/bash

# Installer Calamares
pacman -Sy --noconfirm calamares

# Copier les configurations de Calamares
cp -r /chemin/vers/mes/configurations/calamares /etc/calamares

# Configurer les permissions
chmod -R 755 /etc/calamares
```

### 5. Automatiser le démarrage de Calamares

Configurez `.xinitrc` pour démarrer Calamares automatiquement dans l'environnement live :

```bash
echo "exec calamares" >> /home/liveuser/.xinitrc
```

### 6. Construire et tester l'ISO

Construisez votre image ISO et testez-la pour vous assurer que tout fonctionne correctement :

```bash
cd ~/archlive
sudo ./build.sh -v
```

### Conclusion

Intégrer Calamares peut simplifier l'installation pour les utilisateurs finaux, en fournissant une interface graphique conviviale pour l'installation d'Arch Linux.
