# scripts folder
- For ARM devices, you have to compile C++ files yourself. If there are none, yippee
- It is advised to use services instead of listening/polling scripts, so everything here are just scripts for actions