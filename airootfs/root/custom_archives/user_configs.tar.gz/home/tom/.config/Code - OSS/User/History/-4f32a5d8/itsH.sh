#!/usr/bin/env bash
# install archiso et calamares
USER=tom
yay -Sy --noconfirm  archiso calamares 

cd ~/.
cp -r /usr/share/archiso/configs/releng/* ~/archlive

## nettoyer le systeme de tout ce qui est inutile pour aleger la clefs usb
sudo pacman -Rns \$(pacman -Qtdq)
sudo pacman -Sc

## entrer dans archlive
cd ~/archlive
## ajouter les packages
yay -Qqe > packages.x86_64
mv packages.x86_64 airootfs/.
## ajoutes les etc et ton home
sudo tar -czvf etc_backup.tar.gz /etc/
tar -czvf user_configs.tar.gz /home/$USER/.config /home/$USER/.local /home/$USER/.bin
mkdir -p airootfs/root/custom_archives
mv user_config.tar.gz airootfs/root/custom_archives/.
sudo mv etc_backup.tar.gz airootfs/root/custom_archives/.
chmod 755 ~/archlive/airootfs/root/custom_archives
chmod 644 ~/archlive/airootfs/root/custom_archives/*.tar.gz

## ajoute tes scripts
mkdir -p airootfs/root/scripts
touch airootfs/root/scripts/customize.sh
chmod +x airootfs/root/scripts/customize.sh
echo "#!/usr/bin/env bash" >> airootfs/root/scripts/customize.sh
echo "yay -Sy --noconfirm git" >> airootfs/root/scripts/customize.sh
echo "cd ~/."
echo "git clone https://github.com/tombombadilom/AI-Local-Machine.git" >> airootfs/root/scripts/customize.sh
## ajouter le s


