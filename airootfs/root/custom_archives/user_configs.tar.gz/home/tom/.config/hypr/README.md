# hypr
my personnal Hyprland config
- [GLSL](https://glslsandbox.com)
- [Source](https://github.com/end-4/dots-hyprland)
